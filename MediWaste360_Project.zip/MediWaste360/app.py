from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify, send_file
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime, date
from functools import wraps
from pathlib import Path
import os, csv, io

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "change-this-secret-key")
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///mediwaste.db"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
app.config["UPLOAD_FOLDER"] = "static/uploads"
app.config["MAX_CONTENT_LENGTH"] = 8 * 1024 * 1024
db = SQLAlchemy(app)
Path(app.config["UPLOAD_FOLDER"]).mkdir(parents=True, exist_ok=True)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(30), default="staff")

class WasteRecord(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    department = db.Column(db.String(80), nullable=False)
    waste_type = db.Column(db.String(80), nullable=False)
    category = db.Column(db.String(80), nullable=False)
    quantity = db.Column(db.Float, nullable=False)
    unit = db.Column(db.String(12), default="kg")
    notes = db.Column(db.String(300))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Complaint(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    department = db.Column(db.String(80), nullable=False)
    waste_type = db.Column(db.String(80), nullable=False)
    description = db.Column(db.String(500), nullable=False)
    priority = db.Column(db.String(20), default="Medium")
    status = db.Column(db.String(30), default="Pending")
    image = db.Column(db.String(255))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Collection(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    department = db.Column(db.String(80), nullable=False)
    waste_category = db.Column(db.String(80), nullable=False)
    scheduled_for = db.Column(db.String(30), nullable=False)
    assigned_to = db.Column(db.String(100))
    status = db.Column(db.String(30), default="Scheduled")

class RecyclingListing(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    material = db.Column(db.String(80), nullable=False)
    quantity = db.Column(db.Float, nullable=False)
    department = db.Column(db.String(80), nullable=False)
    partner = db.Column(db.String(100))
    status = db.Column(db.String(30), default="Available")

class AuditLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    actor = db.Column(db.String(120))
    action = db.Column(db.String(300))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

def log(action):
    db.session.add(AuditLog(actor=session.get("name", "System"), action=action))
    db.session.commit()

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("user_id"):
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper

def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if session.get("role") != "admin":
            flash("Admin access required.", "warning")
            return redirect(url_for("dashboard"))
        return fn(*args, **kwargs)
    return wrapper

def classify_item(item):
    """Transparent keyword-based demo classifier; confirm all biomedical decisions with trained staff."""
    s = item.lower()
    if any(x in s for x in ["needle", "blade", "scalpel", "sharp"]):
        return "Biomedical - White (Sharps)"
    if any(x in s for x in ["blood", "dressing", "cotton", "bandage", "soiled"]):
        return "Biomedical - Yellow/Red (verify)"
    if any(x in s for x in ["iv set", "tubing", "plastic syringe", "glove"]):
        return "Biomedical - Red (verify)"
    if any(x in s for x in ["glass", "vial", "ampoule", "metal implant"]):
        return "Biomedical - Blue (verify)"
    if any(x in s for x in ["battery", "monitor", "computer", "charger", "cable", "keyboard"]):
        return "E-waste"
    if any(x in s for x in ["paper", "cardboard", "clean plastic", "bottle"]):
        return "Potentially recyclable (verify)"
    if any(x in s for x in ["food", "vegetable", "fruit", "leftover"]):
        return "General wet / organic"
    return "General / needs staff review"

@app.route("/")
def index():
    if session.get("user_id"):
        return redirect(url_for("dashboard"))
    return render_template("landing.html")

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        user = User.query.filter_by(email=request.form.get("email", "").lower().strip()).first()
        if user and check_password_hash(user.password, request.form.get("password", "")):
            session.update(user_id=user.id, name=user.name, role=user.role)
            log("Logged in")
            return redirect(url_for("dashboard"))
        flash("Invalid email or password.", "danger")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/dashboard")
@login_required
def dashboard():
    total = db.session.query(db.func.sum(WasteRecord.quantity)).scalar() or 0
    records = WasteRecord.query.order_by(WasteRecord.created_at.desc()).limit(6).all()
    complaints = Complaint.query.order_by(Complaint.created_at.desc()).limit(6).all()
    pending = Complaint.query.filter_by(status="Pending").count()
    resolved = Complaint.query.filter_by(status="Resolved").count()
    collections = Collection.query.order_by(Collection.id.desc()).limit(5).all()
    by_cat = db.session.query(WasteRecord.category, db.func.sum(WasteRecord.quantity)).group_by(WasteRecord.category).all()
    by_dept = db.session.query(WasteRecord.department, db.func.sum(WasteRecord.quantity)).group_by(WasteRecord.department).all()
    return render_template("dashboard.html", total=round(total,2), records=records, complaints=complaints,
                           pending=pending, resolved=resolved, collections=collections,
                           chart_labels=[x[0] for x in by_cat], chart_values=[float(x[1]) for x in by_cat],
                           dept_labels=[x[0] for x in by_dept], dept_values=[float(x[1]) for x in by_dept])

@app.route("/waste", methods=["GET", "POST"])
@login_required
def waste():
    if request.method == "POST":
        try:
            q = float(request.form.get("quantity", 0))
            if q <= 0: raise ValueError()
        except ValueError:
            flash("Enter a quantity greater than zero.", "danger")
            return redirect(url_for("waste"))
        rec = WasteRecord(department=request.form["department"], waste_type=request.form["waste_type"],
                          category=request.form["category"], quantity=q, unit=request.form.get("unit","kg"),
                          notes=request.form.get("notes",""))
        db.session.add(rec); db.session.commit(); log(f"Added waste record #{rec.id}")
        flash("Waste record saved.", "success")
        return redirect(url_for("waste"))
    records = WasteRecord.query.order_by(WasteRecord.created_at.desc()).all()
    return render_template("waste.html", records=records)

@app.route("/complaints", methods=["GET", "POST"])
@login_required
def complaints():
    if request.method == "POST":
        image_name = None
        f = request.files.get("image")
        if f and f.filename:
            safe = secure_filename(f.filename)
            image_name = f"{datetime.utcnow().strftime('%Y%m%d%H%M%S')}_{safe}"
            f.save(os.path.join(app.config["UPLOAD_FOLDER"], image_name))
        c = Complaint(department=request.form["department"], waste_type=request.form["waste_type"],
                      description=request.form["description"], priority=request.form.get("priority","Medium"), image=image_name)
        db.session.add(c); db.session.commit(); log(f"Created complaint #{c.id}")
        flash("Complaint submitted successfully.", "success")
        return redirect(url_for("complaints"))
    items = Complaint.query.order_by(Complaint.created_at.desc()).all()
    return render_template("complaints.html", items=items)

@app.route("/complaints/<int:cid>/status", methods=["POST"])
@login_required
def update_complaint(cid):
    c = Complaint.query.get_or_404(cid)
    if session.get("role") != "admin" and session.get("role") != "collector":
        flash("Only admin or collection team can update complaint status.", "warning")
        return redirect(url_for("complaints"))
    status = request.form.get("status")
    if status in ["Pending", "In Progress", "Resolved"]:
        c.status = status
        db.session.commit(); log(f"Updated complaint #{cid} to {status}")
        flash("Complaint status updated.", "success")
    return redirect(url_for("complaints"))

@app.route("/collections", methods=["GET", "POST"])
@login_required
def collections():
    if request.method == "POST":
        item = Collection(department=request.form["department"], waste_category=request.form["waste_category"],
                          scheduled_for=request.form["scheduled_for"], assigned_to=request.form.get("assigned_to",""))
        db.session.add(item); db.session.commit(); log(f"Scheduled collection #{item.id}")
        flash("Collection scheduled.", "success")
        return redirect(url_for("collections"))
    items = Collection.query.order_by(Collection.id.desc()).all()
    return render_template("collections.html", items=items)

@app.route("/collections/<int:cid>/complete", methods=["POST"])
@login_required
def complete_collection(cid):
    item = Collection.query.get_or_404(cid)
    item.status = "Completed"
    db.session.commit(); log(f"Completed collection #{cid}")
    flash("Collection marked completed.", "success")
    return redirect(url_for("collections"))

@app.route("/recycling", methods=["GET", "POST"])
@login_required
def recycling():
    if request.method == "POST":
        try:
            q = float(request.form["quantity"])
            if q <= 0: raise ValueError()
        except ValueError:
            flash("Quantity must be greater than zero.", "danger")
            return redirect(url_for("recycling"))
        r = RecyclingListing(material=request.form["material"], quantity=q, department=request.form["department"])
        db.session.add(r); db.session.commit(); log(f"Created recycling listing #{r.id}")
        flash("Recycling listing created.", "success")
        return redirect(url_for("recycling"))
    items = RecyclingListing.query.order_by(RecyclingListing.id.desc()).all()
    return render_template("recycling.html", items=items)

@app.route("/detection", methods=["GET", "POST"])
@login_required
def detection():
    result = None
    if request.method == "POST":
        item = request.form.get("item", "")
        result = {"item": item, "category": classify_item(item)}
    return render_template("detection.html", result=result)

@app.route("/reports")
@login_required
def reports():
    records = WasteRecord.query.order_by(WasteRecord.created_at.desc()).all()
    return render_template("reports.html", records=records)

@app.route("/reports/export.csv")
@login_required
def export_csv():
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["ID","Department","Waste type","Category","Quantity","Unit","Created at"])
    for r in WasteRecord.query.order_by(WasteRecord.created_at.desc()).all():
        writer.writerow([r.id,r.department,r.waste_type,r.category,r.quantity,r.unit,r.created_at.isoformat()])
    mem = io.BytesIO(output.getvalue().encode("utf-8-sig")); mem.seek(0)
    return send_file(mem, mimetype="text/csv", as_attachment=True, download_name="mediwaste_report.csv")

@app.route("/admin/users", methods=["GET", "POST"])
@login_required
@admin_required
def users():
    if request.method == "POST":
        email = request.form["email"].lower().strip()
        if User.query.filter_by(email=email).first():
            flash("Email already exists.", "danger")
        else:
            u = User(name=request.form["name"], email=email, password=generate_password_hash(request.form["password"]),
                     role=request.form["role"])
            db.session.add(u); db.session.commit(); log(f"Created user {email}")
            flash("User created.", "success")
        return redirect(url_for("users"))
    return render_template("users.html", users=User.query.order_by(User.id.desc()).all())

@app.route("/api/summary")
@login_required
def api_summary():
    return jsonify({"total_waste_kg": float(db.session.query(db.func.sum(WasteRecord.quantity)).scalar() or 0),
                    "pending_complaints": Complaint.query.filter_by(status="Pending").count(),
                    "resolved_complaints": Complaint.query.filter_by(status="Resolved").count()})

def seed():
    db.create_all()
    if not User.query.filter_by(email="admin@mediwaste.local").first():
        db.session.add(User(name="Hospital Admin", email="admin@mediwaste.local",
                            password=generate_password_hash("Admin@123"), role="admin"))
        db.session.add(User(name="Ward Staff", email="staff@mediwaste.local",
                            password=generate_password_hash("Staff@123"), role="staff"))
        db.session.add(User(name="Collection Team", email="collector@mediwaste.local",
                            password=generate_password_hash("Collect@123"), role="collector"))
        db.session.commit()

with app.app_context():
    seed()

if __name__ == "__main__":
    app.run(debug=True)
