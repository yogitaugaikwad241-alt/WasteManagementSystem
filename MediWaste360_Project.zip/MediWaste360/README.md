# MediWaste 360
A software-only hospital waste reporting, classification support, collection scheduling and analytics demo built with Flask, SQLite, SQLAlchemy, Bootstrap, Chart.js and Leaflet.

## Run locally
1. Install Python 3.10+.
2. Open a terminal in this folder.
3. Create a virtual environment (recommended):
   - Windows: `py -m venv .venv` then `.venv\Scripts\activate`
   - macOS/Linux: `python3 -m venv .venv` then `source .venv/bin/activate`
4. Install: `pip install -r requirements.txt`
5. Start: `python app.py`
6. Open `http://127.0.0.1:5000`.

## Demo accounts
- Admin: `admin@mediwaste.local` / `Admin@123`
- Staff: `staff@mediwaste.local` / `Staff@123`
- Collector: `collector@mediwaste.local` / `Collect@123`

Change demo passwords and SECRET_KEY before any real deployment. This is an academic prototype, not a certified biomedical waste compliance system.

## Included modules
- Role-based login (admin, staff, collector)
- Waste records with category, department and quantity
- Waste complaint registration with optional image upload
- Complaint status workflow
- Collection scheduling and completion
- Keyword-based classification assistant (demo, not medical-grade AI)
- Recycling listings
- Dashboard charts and department analytics
- CSV report export
- Admin user creation and audit log model

## Important biomedical waste safety note
Classification output is advisory only. Biomedical waste segregation, packaging, storage, transport, treatment and disposal must be confirmed by trained/authorized personnel under current applicable Indian rules and local pollution control board guidance. Do not use this demo as the sole basis for real-world disposal decisions.
